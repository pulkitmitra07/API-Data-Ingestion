import json
import os
import boto3
import requests
from datetime import datetime

s3 = boto3.client('s3')
bucket_name = os.environ['S3_BUCKET_NAME']
api_key = os.environ['API_KEY']
airvisual_api_key = os.environ['AIRVISUAL_API_KEY']
openweathermap_api_endpoint = "https://api.openweathermap.org/data/2.5/weather"
airvisual_api_endpoint = "https://api.airvisual.com/v2/city"

def extract_weather_data_openweather(location):
    params = {
        'q': location['city'],
        'appid': api_key
    }
    response = requests.get(openweathermap_api_endpoint, params=params)
    response.raise_for_status()
    return response.json()

def extract_weather_data_airvisual(location):
    params = {
        'city': location['city'],
        'state': location['state'],
        'country': location['country'],
        'key': airvisual_api_key
    }
    response = requests.get(airvisual_api_endpoint, params=params)
    response.raise_for_status()
    return response.json()

def transform_data(openweathermap_data, airvisual_data):
    openweathermap_main = openweathermap_data.get('main', {})
    openweathermap_weather = openweathermap_data.get('weather', [{}])[0]
    airvisual_pollution = airvisual_data.get('data', {}).get('current', {}).get('pollution', {})
    airvisual_weather = airvisual_data.get('data', {}).get('current', {}).get('weather', {})

    transformed_data = {
        'location': openweathermap_data.get('name', ''),
        'country': openweathermap_data.get('sys', {}).get('country', ''),
        'weather_description': openweathermap_weather.get('description', ''),
        'temperature_celsius': openweathermap_main.get('temp', 0) - 273.15,  # Convert Kelvin to Celsius
        'humidity': openweathermap_main.get('humidity', 0),
        'wind_speed': openweathermap_data.get('wind', {}).get('speed', 0),
        'air_quality_index': airvisual_pollution.get('aqius', 0),
        'air_quality_category': airvisual_pollution.get('mainus', ''),
        'air_quality_description': airvisual_pollution.get('us', ''),
        'air_visual_weather_description': airvisual_weather.get('tp', ''),
        'cloud_coverage': openweathermap_data.get('clouds', {}).get('all', 0),
        'sunrise': datetime.fromtimestamp(openweathermap_data.get('sys', {}).get('sunrise', 0)).isoformat(),
        'sunset': datetime.fromtimestamp(openweathermap_data.get('sys', {}).get('sunset', 0)).isoformat(),
        'timestamp': datetime.utcfromtimestamp(openweathermap_data.get('dt', 0)).isoformat(),
    }
    return transformed_data

def load_data_to_s3(data):
    object_key = f"weather_data_{datetime.utcnow().isoformat()}.json"
    s3.put_object(
        Body=json.dumps(data),
        Bucket=bucket_name,
        Key=object_key,
        ContentType="application/json"
    )

def handler(event, context):
    try:
        # Extract the location data for both APIs
        openweather_location = event['openweather']
        airvisual_location = event['airvisual']

        # Process OpenWeatherMap data
        openweather_data = extract_weather_data_openweather(openweather_location)

        # Process AirVisual data
        airvisual_data = extract_weather_data_airvisual(airvisual_location)

        # Transform and load data to S3
        transformed_data = transform_data(openweather_data, airvisual_data)
        load_data_to_s3(transformed_data)

        return {
            'statusCode': 200,
            'body': json.dumps('Weather data processed and loaded to S3')
        }
    except Exception as e:
        print(f'Error processing weather data: {e}')
        raise e
